#ifndef TICTACTOE_CPP
#define TICTACTOE_CPP

#include "Grille.h"
#include "Tictactoe.h"
#include <iostream>


    Tictactoe::Tictactoe() : _symboleCourant('X'),_numeroTour(0) {}

    void Tictactoe::afficheGrille(){
        // à compléter
    }

    void Tictactoe::ajouteSymbole(int x, int y){
        // à compléter
    }

    bool Tictactoe::testeVictoireVerticale(){
        // à compléter
    }

    bool Tictactoe::testeVictoireHorizontale(){
        // à compléter 
    }

    bool Tictactoe::testeVictoireDiagonale(){
        // à compléter
    }

    bool Tictactoe::testeJeuNul(){
        // à compléter
    }

    void Tictactoe::finTour(){
        // à compléter
   }

#endif